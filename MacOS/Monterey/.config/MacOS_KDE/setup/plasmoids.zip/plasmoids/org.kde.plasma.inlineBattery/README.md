# Mac Inline Battery
🔋 Mac-like Inline Battery Plasmoid for KDE

## Install
```
kpackagetool5 -t Plasma/Applet --install .
```

## Development
```
kpackagetool5 -t Plasma/Applet --upgrade .
```

## Uninstall
```
kpackagetool5 -t Plasma/Applet --remove org.kde.plasma.inlineBattery
```
